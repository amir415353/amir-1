# Auto Join Channel (/join)
# Chris Crypto Gaming & Financials
# Youtube Channel : http://bit.ly/CCGYTC
# E-mail : chriscryptogaming@gmail.com
# ETH Donations : 0xf410dCC5b41BF683390aCF0d6D2f0CCb198f3f86
# BTC Donations : 1C7SVC1mPBcXPYwq2jM765MKgQLm1S7DkY
# Doge Donations : DDn8sexiCcpi4MSCA1NPGz3G6vJLFRUKQj
# ZEC Donations : t1SgzYXhusasn7xaMzBhqE3Lfx4fBfrEFyF
# LTC Donations : ltc1qqwzdz03z6h5y5382lgvyhsuykzcrz580mj89u9
# BCH Donations : qqzjvgs0s2leev5gtam6cfm6fqch0kxw9q3narmjj4
# LTC Clickbot : http://bit.ly/35ME9Cq
# Doge Clickbot : http://bit.ly/35RO21J
# ZEC Clickbot : http://bit.ly/37WdN2L
# BTC Clickbot : http://bit.ly/2sAM1Zz
# BCH Clickbot : http://bit.ly/2R9GymM
# Support us on Brave! : http://bit.ly/CCGBrave

#Imports
import asyncio
import logging
import re
import time
import os
import sys
import requests
logging.basicConfig(level=logging.ERROR)

from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from datetime import datetime
from colorama import Fore, init as color_ama
color_ama(autoreset=True)

os.system('cls' if os.name=='nt' else 'clear')

# my.telegram.org values, get your own there
api_id = 1127509
api_hash = '7919be907884f1d388803b03f1994d78'

dogeclick_channel = 'Litecoin_click_bot'

# Date & Time Header
def print_msg_time(message):
    print('[' + Fore.YELLOW + f'{datetime.now().strftime("%H:%M:%S")}' + Fore.RESET + f'] {message}')

#Personalized Message
async def main():

    print(Fore.RED       + '       )  (    (    (              (        )  (               ) ')
    print(Fore.RED       + ' (    ( /(  )\ ) )\ ) )\ )      (    )\ )  ( /(  )\ )  *   )  ( /( ')
    print(Fore.RED       + '  )\   )\())(()/((()/((()/(      )\  (()/(  )\())(()/(` )  /(  )\()) ')
    print(Fore.YELLOW    + ' (((_) ((_)\  /(_))/(_))/(_))   (((_)  /(_))((_)\  /(_))( )(_))((_)\ ')
    print(Fore.YELLOW    + ') )\___  _((_)(_)) (_)) (_))     )\___ (_)) __ ((_)(_)) (_(_())  ((_) ')
    print(Fore.YELLOW    + ')((/ __|| || || _ \|_ _|/ __|   ((/ __|| _ \ \ \ / /| _ \|_   _| / _ \ ')
    print(Fore.BLUE      + ' )| (__ | __ ||   / | | \__ \    | (__ |   /  \ V / |  _/  | |  | (_) |')
    print(Fore.BLUE      + '  \____||_||_||_|_\|___||___/     \___||_|_\   |_|  |_|    |_|   \___/ \n' + Fore.RESET)
    print(Fore.BLUE   + '                      BY :CHRIS CRYPTO GAMING \n' + Fore.RESET)
    print(Fore.BLUE   + '                  YT Channel : http://bit.ly/CCGYTC  \n' + Fore.RESET)



    # Check if phone number is not specified
    if len(sys.argv) < 2:
        print('Usage: python start.py phone_number')
        print('-> Input number in international format (example: +10123456789)\n')
        e = input('Press any key to exit...')
        exit(1)

    phone_number = sys.argv[1]

    if not os.path.exists("session"):
        os.mkdir("session")

    # Connect to client
    client = TelegramClient('session/' + phone_number, api_id, api_hash)
    await client.start(phone_number)
    me = await client.get_me()

    # Current account & username
    print(Fore.GREEN + f'               Current account: {me.first_name}({me.username})\n' + Fore.RESET)
    print_msg_time('Sending /join command')

    # Start command /join
    await client.send_message(dogeclick_channel, '/join')

    # Join channel
    @client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
    async def join_start(event):
        try:
            message = event.raw_text
            if 'After joining the group' in message:
                print_msg_time(f'skip group!...')

                # Clicks joined button
                await client(GetBotCallbackAnswerRequest(
                    peer=dogeclick_channel,
                    msg_id=event.message.id,
                    data=event.message.reply_markup.rows[1].buttons[1].data
                ))
            # Join channel
            elif 'After joining the channel' in message:
                channel_name = re.search(r'You must join @(.*?) to earn', message).group(1)
                print_msg_time(f'Joining @{channel_name}...')

                # Verifying Join
                await client(JoinChannelRequest(channel_name))
                print_msg_time(f'Verifying...')

                # Clicks joined button
                await client(GetBotCallbackAnswerRequest(
                    peer=dogeclick_channel,
                    msg_id=event.message.id,
                    data=event.message.reply_markup.rows[0].buttons[1].data
                ))
        except ValueError:
            await client(GetBotCallbackAnswerRequest(
                peer=dogeclick_channel,
                msg_id=event.message.id,
                data=event.message.reply_markup.rows[0].buttons[1].data
            ))


    # Print waiting hours
    @client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
    async def wait_hours(event):
        message = event.raw_text
        if 'You must stay' in message:
            waiting_hours = re.search(r'at least (.*?) to earn', message).group(1)
            print_msg_time(Fore.GREEN + f'Success! Please wait {waiting_hours} to earn reward\n' + Fore.RESET)

    # No more ads
    @client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
    async def no_ads(event):
        message = event.raw_text
        if 'no new ads available' in message:
            print_msg_time(Fore.RED + 'Sorry, there are no new ads available\n' + Fore.RESET)


    # No more ads - balance inquiry - close
    @client.on(events.NewMessage(chats=dogeclick_channel, incoming=True))
    async def no_ads(event):
        message = event.raw_text
        if 'Sorry,' in message:
            await client.send_message(dogeclick_channel, '/balance')
        if 'Available balance:' in message:
            print_msg_time(Fore.GREEN + event.raw_text + '\n' + Fore.RESET)



            exit(1)
    await client.run_until_disconnected()

asyncio.get_event_loop().run_until_complete(main())
